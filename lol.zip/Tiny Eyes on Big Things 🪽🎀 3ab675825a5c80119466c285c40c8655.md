# Tiny Eyes on Big Things 🪽🎀

[Discord Link 🔗](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/Discord%20Link%20%F0%9F%94%97%203ab675825a5c80529435eef4fc393da1.md)

> ***Strict pro-a4a/wl motivation space for real ones only. Don’t join if you know you’re a pussy.***
> 

[Rules 💌](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/Rules%20%F0%9F%92%8C%203ab675825a5c80be8d86e73fa8da8efb.md)

[How To Join / What To Do When You First Get In 🍧](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/How%20To%20Join%20What%20To%20Do%20When%20You%20First%20Get%20In%20%F0%9F%8D%A7%203ab675825a5c809faf8af15af2477d9b.md)

[Q&A 🍭](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/Q&A%20%F0%9F%8D%AD%203ab675825a5c80c2ab00cd01158396fe.md)

[Resources 🔆](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/Resources%20%F0%9F%94%86%203ab675825a5c801689ccdb0519940b2a.md)

[Cassie (Skins UK ⭐️🪽) ](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/v15044gf0000d9hl6ofog65v3jkh059g.mp4)

Cassie (Skins UK ⭐️🪽) 

[***you wanna be th1n? 🩵***](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/you%20wanna%20be%20th1n%20%F0%9F%A9%B5%203ab675825a5c805e98c8f18931bbc471.md)

[signup for the newsletter 🤍](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/signup%20for%20the%20newsletter%20%F0%9F%A4%8D%203ab675825a5c80f780e5de2265a45bb2.md)

[recruit a friend 👩🏼‍🐰‍👩🏽](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/recruit%20a%20friend%20%F0%9F%91%A9%F0%9F%8F%BC%E2%80%8D%F0%9F%90%B0%E2%80%8D%F0%9F%91%A9%F0%9F%8F%BD%203ab675825a5c80849f9cfebc0530a273.md)

<aside>
<img src="Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/IMG_6190.jpeg" alt="Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/IMG_6190.jpeg" width="40px" />

PRO ANA SITES 

</aside>

⋆‧°𓏲ּ𝄢 ꩜｡**WARNING- Almost every site is from 2018 or before so many images and/or links are broken/janky!!**

[Eating Disorder Central](https://eatingdisordercentral.com/)

[Ana Tips and Tricks](https://anapure.weebly.com/ana-tips-and-tricks.html)

[Shy Bones Talks Proana](https://shybonestalksproana.weebly.com/advise-and-tips.html)

[Fading Obsessions](https://fadingobsessions.com/foinsider/about-us.php) 

[ON YOUR WAY 2 SKINNY](https://proana-thinspo.weebly.com/)

[Thin Thighs](https://t.co/B48GNBuong) 

[Ana is my Religion](https://t.co/jBZ6tbc5aL)

[Prostarvation](https://t.co/i7kxNOpImV)

[Proana Goddess](https://t.co/RxZXlVkIK7)

[Ana Angels](https://anaangels.wordpress.com/2016/12/07/my-first-day/)

[Bulimic Bible](https://t.co/5uXQgL9Igf)

[Porcelain Legs](https://t.co/aOuPmjU8ua)

[Butterfly of Secrets](https://t.co/gXjQP6i0HS)

[ED SUPPORT FORUM](https://www.edsupportforum.com/forums/)

![IMG_6191.jpeg](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/IMG_6191.jpeg)

---

[EXERCISES 😋](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/EXERCISES%20%F0%9F%98%8B%203ab675825a5c8044a39ec37a3e2f2368.md)

[Tips to Not Binge or Overeat at night!](https://youtu.be/ey9rd5vdUVE?is=AbtpOpnwVPcIS59p)

[thigh gap af](https://youtu.be/PLOFZwU5nCc?is=vV23DWi47W246G03)

[Current Challenges 🪽](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/Current%20Challenges%20%F0%9F%AA%BD%203b8675825a5c808fa603d1b53ea95ee2.md)

[Member Spotlight 🦴](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/Member%20Spotlight%20%F0%9F%A6%B4%203b8675825a5c80fe9f6cf8ff3b1c1c0c.md)

[https://open.spotify.com/playlist/7q5afbn8MZwiJolzB0oKdP?si=euolERX9Sayo0ka8VRM4WQ&utm_source=copy-link&pi=xtjoBHmzRxeor](https://open.spotify.com/playlist/7q5afbn8MZwiJolzB0oKdP?si=euolERX9Sayo0ka8VRM4WQ&utm_source=copy-link&pi=xtjoBHmzRxeor)

[export_1786434602118.mov](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/export_1786434602118.mov)

[TIPS 101 🍓🍒](Tiny%20Eyes%20on%20Big%20Things%20%F0%9F%AA%BD%F0%9F%8E%80/TIPS%20101%20%F0%9F%8D%93%F0%9F%8D%92%203b9675825a5c80dc8600c3b52bf1a046.md)