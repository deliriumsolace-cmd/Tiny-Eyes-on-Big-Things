# signup for the newsletter 🤍

Owner: tiny eyes on big things 🍓

[https://it-girl-intake-newsletter.beehiiv.com/](https://it-girl-intake-newsletter.beehiiv.com/)