# Rules 💌

Owner: tiny eyes on big things 🍓

- be kind to the other dolls, but honest
- check-ins are expected, silence is temporary
- no recovery talk, this is a soft space for getting smaller
- keep personal info private
- no judging other girls’ numbers or methods
- if you’re not ready to commit, this isn’t your place
- respect the mods and the energy
- we shrink together or we leave quietly