# measurement guide (waist, thighs, etc.)

Owner: tiny eyes on big things 🍓

1. waist: right at the belly button, standing relaxed
2. hips: widest part
3. thighs: right under the butt, both sides
4. arms: mid-bicep
5. measure once a week at the same time of day 
6. take the number even if you don’t like it; ***tracking is the point***

![IMG_6165.webp](measurement%20guide%20(waist,%20thighs,%20etc%20)/IMG_6165.webp)