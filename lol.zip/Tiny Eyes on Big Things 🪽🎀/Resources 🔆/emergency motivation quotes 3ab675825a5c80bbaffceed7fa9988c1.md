# emergency motivation quotes

Owner: tiny eyes on big things 🍓

> If you need to undress to weigh yourself, then you’re already too big.
> 

![IMG_5744.jpeg](emergency%20motivation%20quotes/IMG_5744.jpeg)

![IMG_5995.jpeg](emergency%20motivation%20quotes/IMG_5995.jpeg)

![temp_image_F9ABE971-7A35-48AA-98D6-1F41E2964953.webp](emergency%20motivation%20quotes/temp_image_F9ABE971-7A35-48AA-98D6-1F41E2964953.webp)

![temp_image_15DAECC0-184A-40EC-8A6F-0A800B9F0E7A.webp](emergency%20motivation%20quotes/temp_image_15DAECC0-184A-40EC-8A6F-0A800B9F0E7A.webp)

![IMG_6039.jpeg](emergency%20motivation%20quotes/IMG_6039.jpeg)

![IMG_6040.jpeg](emergency%20motivation%20quotes/IMG_6040.jpeg)

![IMG_6067.jpeg](emergency%20motivation%20quotes/IMG_6067.jpeg)

![IMG_6066.jpeg](emergency%20motivation%20quotes/IMG_6066.jpeg)

![IMG_6068.jpeg](emergency%20motivation%20quotes/IMG_6068.jpeg)

![IMG_6069.jpeg](emergency%20motivation%20quotes/IMG_6069.jpeg)

![IMG_2351.jpeg](emergency%20motivation%20quotes/IMG_2351.jpeg)

![IMG_6071.jpeg](emergency%20motivation%20quotes/IMG_6071.jpeg)

![IMG_6073.jpeg](emergency%20motivation%20quotes/IMG_6073.jpeg)

![IMG_6074.jpeg](emergency%20motivation%20quotes/IMG_6074.jpeg)

![IMG_6072.jpeg](emergency%20motivation%20quotes/IMG_6072.jpeg)

![IMG_6124.jpeg](emergency%20motivation%20quotes/IMG_6124.jpeg)

![IMG_6126.jpeg](emergency%20motivation%20quotes/IMG_6126.jpeg)

![IMG_6127.jpeg](emergency%20motivation%20quotes/IMG_6127.jpeg)

![IMG_6128.jpeg](emergency%20motivation%20quotes/IMG_6128.jpeg)

![IMG_6131.jpeg](emergency%20motivation%20quotes/IMG_6131.jpeg)

![IMG_6129.jpeg](emergency%20motivation%20quotes/IMG_6129.jpeg)

![IMG_6130.jpeg](emergency%20motivation%20quotes/IMG_6130.jpeg)

![IMG_6146.jpeg](emergency%20motivation%20quotes/IMG_6146.jpeg)