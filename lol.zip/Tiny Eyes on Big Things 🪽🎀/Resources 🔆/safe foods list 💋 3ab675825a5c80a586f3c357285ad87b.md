# safe foods list 💋

Owner: tiny eyes on big things 🍓

- cucumber
- celery
- strawberries
- rice cakes
- sugar-free jello
- broth
- black coffee / tea
- gum
- tiny portion of egg whites or plain grilled chicken if you need something more

![IMG_6072.jpeg](safe%20foods%20list%20%F0%9F%92%8B/IMG_6072.jpeg)