# fasting tips & schedules 🧐

Owner: tiny eyes on big things 🍓

1. start with 16:8 if you’re new (eat in an 8-hour window, fast the other 16) move to OMAD when that gets easy
2. longer fasts (24-48h) only when you already feel in control
3. water, black coffee, tea, and gum are fine during the fast
4. weigh every morning, same time, no clothes
5. if you feel dizzy, sit down and sip water with salt; don’t panic eat
6. the first 3 days are the hardest, after that it gets quieter

![IMG_6166.jpeg](fasting%20tips%20&%20schedules%20%F0%9F%A7%90/IMG_6166.jpeg)