# recruit a friend 👩🏼‍🐰‍👩🏽

Owner: tiny eyes on big things 🍓

**ready-made captions for TikTok/IG 🎀**

- “looking for soft girls who get it ⋆˙⟡ dm for the private server”
- “if you’re tired of fake motivation and actually want to shrink… link in bio / dm me”
- “strict space, real check-ins, no recovery talk. only serious dolls”
- “wl server, we post daily small, we don’t play. dm for invite”

**hashtag lists** 🧚🏽

Main: #thinspo #proana #bonespo #fasting #underweight #skinnygirls #edtwt #wlcommunity #wl #edtwt #edtt #ana #€d #ednotshereen 

Aesthetic mix: #coquette #lolita #dollcore #softgirl #childaesthetic #porcelainskin #babygirl #lanadelrey 

Extra: #bodycheck #glowup #itgirl #maincharacter #collegegirl #omad #fasting #⭐️🪽

**“dm me for the link” scripts (anyone you see on tiktok promoting wl/a4a) 💞**

- “hey, saw your page and thought you might like our server. it’s private and pretty strict, want the link?”
- “if you’re looking for real accountability and girls who actually get smaller, i can send the invite”
- “heyyy girliee!! wanna join my wl server?”