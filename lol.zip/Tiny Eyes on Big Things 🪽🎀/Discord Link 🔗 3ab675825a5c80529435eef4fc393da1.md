# Discord Link 🔗

Owner: tiny eyes on big things 🍓

[https://discord.gg/uSKegpYjF](https://discord.gg/uSKegpYjF) 🛼🛼

![IMG_6195.jpeg](Discord%20Link%20%F0%9F%94%97/IMG_6195.jpeg)