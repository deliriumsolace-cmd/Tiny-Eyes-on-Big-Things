# How To Join / What To Do When You First Get In 🍧

Owner: tiny eyes on big things 🍓

1. click the discord link and submit your application 
2. read the rules in the rules channel
3. introduce yourself in the intro channel (keep it soft)
4. post your first check-in (scale or body pic) when you’re ready
5. say hi to a few girls so you don’t stay a ghost
6. mute what you need to, but stay active
7. stay consistent and visit the server at least 2x daily; inactive members will be ***banned***. 
8. No recovery talk or immediate ban.